const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());

const PORT = 3000;

const API_KEY = "Your_Api_Key_Here";

app.get("/games/:steamid", async (req, res) => {
    try {
        const steamid = req.params.steamid;
        const response = await fetch(
            `https://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/?key=${API_KEY}&steamid=${steamid}&format=json&include_appinfo=1`
        );

        const data = await response.json();

        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get("/user/:steamid", async (req, res) => {
    try {
        const steamid = req.params.steamid;
        const response = await fetch(
            `https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=${API_KEY}&steamids=${steamid}&format=json`
        );

        const data = await response.json();

        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.get("/achievment/:appid",async (req,res)=>{
    try{
        const appid = req.params.appid
        const response = await fetch(`https://api.steampowered.com/ISteamUserStats/GetSchemaForGame/v2/?key=${API_KEY}&appid=${appid}`)
        const data = await response.json();
        res.json(data)
    }catch(err){
        res.status(500).json({error:err.message});
    }
})
app.get("/unlocked/:steamid/:appid",async (req,res)=>{
    try{
        const appid = req.params.appid
        const steamid = req.params.steamid
        const response = await fetch(`https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v0001/?appid=${appid}&key=4E05509263A433352E2117FB636D74AA&steamid=${steamid}&format=json&include_appinfo=1`)
        const data = await response.json();
        res.json(data)
    }catch(err){
        res.status(500).json({error:err.message});
    }
})
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});